alter table profiles add column if not exists photo text not null default '';

update profiles set photo = '/guests/marion.jpg' where user_id = 'seed:marion';
update profiles set photo = '/guests/julian.jpg' where user_id = 'seed:julian';
update profiles set photo = '/guests/ade.jpg' where user_id = 'seed:ade';
update profiles set photo = '/guests/rosa.jpg' where user_id = 'seed:rosa';
update profiles set photo = '/guests/kenji.jpg' where user_id = 'seed:kenji';
update profiles set photo = '/guests/elena.jpg' where user_id = 'seed:elena';
update profiles set photo = '/guests/marcus.jpg' where user_id = 'seed:marcus';
update profiles set photo = '/guests/priya.jpg' where user_id = 'seed:priya';
update profiles set photo = '/guests/solomon.jpg' where user_id = 'seed:solomon';
update profiles set photo = '/guests/nico.jpg' where user_id = 'seed:nico';
update profiles set photo = '/guests/claire.jpg' where user_id = 'seed:claire';
update profiles set photo = '/guests/rafael.jpg' where user_id = 'seed:rafael';
