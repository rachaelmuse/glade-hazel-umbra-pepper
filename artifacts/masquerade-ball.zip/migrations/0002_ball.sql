create table if not exists profiles (
  user_id text primary key,
  display_name text not null,
  age integer not null check (age >= 18 and age <= 99),
  city text not null,
  here_as text not null,
  open_to text not null,
  looking_for text not null,
  bio text not null default '',
  mask text not null,
  is_seed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists invitations (
  id serial primary key,
  from_id text not null,
  to_id text not null,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  unique (from_id, to_id)
);
create index if not exists invitations_to_id_idx on invitations (to_id);
create index if not exists invitations_from_id_idx on invitations (from_id);

create table if not exists messages (
  id serial primary key,
  thread_key text not null,
  sender_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists messages_thread_key_idx on messages (thread_key, created_at);

create table if not exists blocks (
  user_id text not null,
  blocked_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, blocked_id)
);
