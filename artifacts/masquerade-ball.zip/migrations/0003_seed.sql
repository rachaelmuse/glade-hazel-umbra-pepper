insert into profiles (user_id, display_name, age, city, here_as, open_to, looking_for, bio, mask, is_seed)
values
  ('seed:marion', 'Marion', 54, 'New Orleans', 'woman', 'everyone', 'company', 'I keep a small table near the jazz. I cook too much on Sundays and I would rather hear about your week than the news.', 'rose', true),
  ('seed:julian', 'Julian', 38, 'Chicago', 'man', 'men', 'lasting', 'Architect by day. I walk the lakefront when the wind is rude. Looking for someone who likes slow evenings and sharp jokes.', 'compass', true),
  ('seed:ade', 'Ade', 41, 'Atlanta', 'woman', 'women', 'conversation', 'Librarian energy, dancer when the right song plays. Bring a book or a story. I will bring the porch light.', 'moth', true),
  ('seed:rosa', 'Rosa', 62, 'Miami', 'woman', 'everyone', 'dancing', 'I still take the long way home. Salsa on Fridays, crossword at dawn. I like people who are done performing.', 'pearl', true),
  ('seed:kenji', 'Kenji', 35, 'Seattle', 'man', 'everyone', 'company', 'I make ceramics that do not match. Rain is a feature. Want someone to cook for, and to be cooked for.', 'fox', true),
  ('seed:elena', 'Elena', 47, 'Santa Fe', 'woman', 'men', 'lasting', 'Painter. I keep odd hours and better coffee. I am here for a person, not an audience.', 'lyre', true),
  ('seed:marcus', 'Marcus', 29, 'Brooklyn', 'man', 'everyone', 'dancing', 'DJ on weekends, quiet the rest of the week. I like rooftops, night buses, and people who tell the truth gently.', 'flame', true),
  ('seed:priya', 'Priya', 44, 'Austin', 'woman', 'everyone', 'conversation', 'I garden like it is an argument I intend to win. Tell me what you are building. I will tell you about the tomatoes.', 'ivy', true),
  ('seed:solomon', 'Solomon', 58, 'Detroit', 'man', 'women', 'company', 'Retired from rushing. I restore old radios. If you like sitting without filling the air, we will get along.', 'coin', true),
  ('seed:nico', 'Nico', 33, 'Portland', 'nonbinary', 'everyone', 'conversation', 'I write letters I never send, then send the good ones. Looking for a mind I want to keep talking to.', 'veil', true),
  ('seed:claire', 'Claire', 51, 'Philadelphia', 'woman', 'women', 'lasting', 'Museum educator. I pack picnics like they are expeditions. Soft launch, long game.', 'swan', true),
  ('seed:rafael', 'Rafael', 40, 'San Juan', 'man', 'everyone', 'dancing', 'I laugh too loud and I am not sorry. The ocean is my church. Come if you like salt and second chances.', 'crescent', true)
on conflict (user_id) do nothing;
