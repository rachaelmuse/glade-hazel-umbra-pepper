import { LOOKING_LABEL, milesAway, type Profile } from "@/lib/ball/types";
import { cn } from "@/lib/utils";

export function photoFor(guest: Profile): string {
  if (guest.photo) return guest.photo;
  if (guest.userId.startsWith("seed:")) {
    return `/guests/${guest.userId.slice(5)}.jpg`;
  }
  return "";
}

export function GuestCard({
  guest,
  likeOpacity = 0,
  nopeOpacity = 0,
  className,
}: {
  guest: Profile;
  likeOpacity?: number;
  nopeOpacity?: number;
  className?: string;
}) {
  const src = photoFor(guest);
  const miles = milesAway(guest.userId);

  return (
    <article
      className={cn(
        "relative isolate h-full overflow-hidden rounded-xl bg-elevated shadow-border",
        className,
      )}
    >
      {src ? (
        <img
          src={src}
          alt=""
          draggable={false}
          className="absolute inset-0 size-full object-cover"
          crossOrigin="anonymous"
        />
      ) : (
        <div className="absolute inset-0 grid place-items-center bg-elevated font-display text-7xl text-muted">
          {guest.displayName.slice(0, 1)}
        </div>
      )}

      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/75 to-transparent px-5 pb-5 pt-28">
        <h2 className="font-display text-4xl leading-none tracking-display text-fg">
          {guest.displayName}
          <span className="text-3xl text-muted">, {guest.age}</span>
        </h2>
        <p className="mt-2 text-sm text-muted">
          {guest.city} · {miles} mile{miles === 1 ? "" : "s"} away
        </p>
        <p className="mt-2 text-xs font-medium tracking-label text-subtle uppercase">
          Here for {LOOKING_LABEL[guest.lookingFor]}
        </p>
        <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-fg">
          {guest.bio}
        </p>
      </div>

      {likeOpacity > 0.04 ? (
        <Stamp
          label="Like"
          className="left-5 top-8 -rotate-[18deg] border-accent text-accent"
          opacity={likeOpacity}
        />
      ) : null}
      {nopeOpacity > 0.04 ? (
        <Stamp
          label="Nope"
          className="right-5 top-8 rotate-[18deg] border-muted text-muted"
          opacity={nopeOpacity}
        />
      ) : null}
    </article>
  );
}

function Stamp({
  label,
  className,
  opacity,
}: {
  label: string;
  className: string;
  opacity: number;
}) {
  return (
    <div
      className={cn(
        "pointer-events-none absolute rounded-md border-2 px-3 py-1 font-display text-3xl uppercase tracking-kicker",
        className,
      )}
      style={{ opacity }}
      aria-hidden
    >
      {label}
    </div>
  );
}

export function GuestThumb({
  guest,
  className = "size-12",
}: {
  guest: Profile;
  className?: string;
}) {
  const src = photoFor(guest);
  return (
    <div className={cn("overflow-hidden rounded-md bg-elevated", className)}>
      {src ? (
        <img
          src={src}
          alt=""
          draggable={false}
          className="size-full object-cover"
          crossOrigin="anonymous"
        />
      ) : (
        <span className="grid size-full place-items-center text-sm text-muted">
          {guest.displayName.slice(0, 1)}
        </span>
      )}
    </div>
  );
}

export function MatchTile({
  guest,
  onClick,
  footer,
}: {
  guest: Profile;
  onClick?: () => void;
  footer?: string;
}) {
  const src = photoFor(guest);
  const inner = (
    <>
      {src ? (
        <img
          src={src}
          alt=""
          draggable={false}
          className="absolute inset-0 size-full object-cover"
          crossOrigin="anonymous"
        />
      ) : (
        <span className="absolute inset-0 grid place-items-center bg-elevated font-display text-4xl text-muted">
          {guest.displayName.slice(0, 1)}
        </span>
      )}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg to-transparent px-3 pb-3 pt-12">
        <p className="truncate font-display text-xl tracking-display text-fg">
          {guest.displayName}, {guest.age}
        </p>
        {footer ? <p className="truncate text-xs text-muted">{footer}</p> : null}
      </div>
    </>
  );

  const cls =
    "relative aspect-portrait w-full overflow-hidden rounded-lg bg-elevated text-left shadow-border";

  if (onClick) {
    return (
      <button type="button" onClick={onClick} className={cls}>
        {inner}
      </button>
    );
  }
  return <div className={cls}>{inner}</div>;
}
