"use client";

import { useState } from "react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Brand, BallShell } from "@/components/ball/shell";
import { Floor } from "@/components/ball/floor";
import type { Profile } from "@/lib/ball/types";

export function BallHome({ initialGuests }: { initialGuests: Profile[] }) {
  const { user } = useCurrentUserState();
  if (user) return <BallShell userId={user.id} />;
  return <PublicDiscover initialGuests={initialGuests} />;
}

function PublicDiscover({ initialGuests }: { initialGuests: Profile[] }) {
  const [guests, setGuests] = useState<Profile[]>(initialGuests);

  return (
    <main className="relative flex min-h-dvh flex-col overflow-hidden bg-bg text-fg overscroll-none">
      <div className="hero-wash pointer-events-none absolute inset-0" aria-hidden />
      <header className="relative z-10 mx-auto flex h-14 w-full max-w-lg shrink-0 items-center justify-between px-5">
        <Brand />
        <a
          href="/login"
          className="inline-flex h-11 items-center text-sm font-medium text-muted hover:text-fg"
        >
          Sign in
        </a>
      </header>
      <div className="relative z-10 mx-auto flex min-h-0 w-full max-w-lg flex-1 flex-col px-4 pb-5">
        <Floor
          guests={guests}
          signedIn={false}
          onChanged={() => setGuests((prev) => prev.slice(1))}
        />
      </div>
    </main>
  );
}
