"use client";

import { useState, type FormEvent, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { saveProfile } from "@/lib/ball/actions";
import {
  HERE_AS,
  HERE_LABEL,
  LOOKING_FOR,
  LOOKING_LABEL,
  OPEN_TO,
  OPEN_LABEL,
  type HereAs,
  type LookingFor,
  type OpenTo,
  type Profile,
} from "@/lib/ball/types";
import { cn } from "@/lib/utils";

type Props = {
  existing?: Profile | null;
  onSaved: () => void;
};

export function Cloakroom({ existing, onSaved }: Props) {
  const [displayName, setDisplayName] = useState(existing?.displayName ?? "");
  const [age, setAge] = useState(existing ? String(existing.age) : "");
  const [city, setCity] = useState(existing?.city ?? "");
  const [hereAs, setHereAs] = useState<HereAs>(existing?.hereAs ?? "woman");
  const [openTo, setOpenTo] = useState<OpenTo>(existing?.openTo ?? "everyone");
  const [lookingFor, setLookingFor] = useState<LookingFor>(
    existing?.lookingFor ?? "dancing",
  );
  const [bio, setBio] = useState(existing?.bio ?? "");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    const years = Number(age);
    if (!Number.isInteger(years) || years < 18) {
      setError("You need to be 18 or over.");
      return;
    }
    setBusy(true);
    try {
      await saveProfile({
        data: {
          displayName,
          age: years,
          city,
          hereAs,
          openTo,
          lookingFor,
          bio,
          mask: existing?.mask ?? "rose",
        },
      });
      onSaved();
    } catch {
      setError("Couldn’t save. Try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="mx-auto flex w-full max-w-lg flex-col gap-6 pb-8">
      <header className="flex flex-col gap-2">
        <p className="text-xs font-medium tracking-kicker text-subtle uppercase">
          Your profile
        </p>
        <h1 className="font-display text-4xl tracking-display">
          {existing ? "Edit profile" : "Set up your profile"}
        </h1>
        <p className="text-pretty text-sm leading-relaxed text-muted">
          Name, city, what you’re here for. That’s enough.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Name">
          <Input
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            maxLength={32}
            required
            autoComplete="nickname"
          />
        </Field>
        <Field label="Age">
          <Input
            value={age}
            onChange={(e) => setAge(e.target.value)}
            inputMode="numeric"
            required
          />
        </Field>
      </div>

      <Field label="City">
        <Input
          value={city}
          onChange={(e) => setCity(e.target.value)}
          maxLength={40}
          required
        />
      </Field>

      <Field label="I am">
        <ChoiceRow
          value={hereAs}
          options={HERE_AS.map((value) => ({ value, label: HERE_LABEL[value] }))}
          onChange={setHereAs}
        />
      </Field>

      <Field label="Looking at">
        <ChoiceRow
          value={openTo}
          options={OPEN_TO.map((value) => ({ value, label: OPEN_LABEL[value] }))}
          onChange={setOpenTo}
        />
      </Field>

      <Field label="Here for">
        <ChoiceRow
          value={lookingFor}
          options={LOOKING_FOR.map((value) => ({
            value,
            label: LOOKING_LABEL[value],
          }))}
          onChange={setLookingFor}
        />
      </Field>

      <Field label="About you">
        <Textarea
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          maxLength={280}
          placeholder="A few lines. What you like. How you spend a Sunday."
        />
      </Field>

      {error ? <p className="text-sm text-muted">{error}</p> : null}

      <Button type="submit" size="lg" disabled={busy} className="w-full">
        {busy ? "Saving" : existing ? "Save" : "Start dating"}
      </Button>
    </form>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function ChoiceRow<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          aria-pressed={value === option.value}
          onClick={() => onChange(option.value)}
          className={cn(
            "h-11 rounded-md px-3 text-sm font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
            value === option.value
              ? "bg-accent text-accent-fg"
              : "bg-elevated text-muted shadow-border hover:text-fg",
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}
