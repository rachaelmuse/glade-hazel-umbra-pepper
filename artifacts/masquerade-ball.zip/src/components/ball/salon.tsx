"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { GuestThumb } from "@/components/ball/guest-card";
import { blockGuest, listMessages, sendMessage } from "@/lib/ball/actions";
import type { Message, Thread } from "@/lib/ball/types";
import { cn } from "@/lib/utils";

type Props = {
  meId: string;
  threads: Thread[];
  openId: string | null;
  onOpen: (id: string | null) => void;
  onChanged: () => void;
};

export function Salon({ meId, threads, openId, onOpen, onChanged }: Props) {
  const current = threads.find((t) => t.other.userId === openId) ?? null;

  if (current) {
    return (
      <Conversation
        meId={meId}
        thread={current}
        onBack={() => onOpen(null)}
        onChanged={onChanged}
      />
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <header className="flex flex-col gap-1">
        <h1 className="font-display text-4xl tracking-display">Chat</h1>
        <p className="text-sm text-muted">
          {threads.length === 0
            ? "Match with someone, then talk here."
            : `${threads.length} conversation${threads.length === 1 ? "" : "s"}`}
        </p>
      </header>
      {threads.length === 0 ? null : (
        <ul className="flex flex-col gap-2">
          {threads.map((thread) => (
            <li key={thread.other.userId}>
              <button
                type="button"
                onClick={() => onOpen(thread.other.userId)}
                className="flex w-full items-center gap-3 rounded-lg bg-surface p-3 text-left shadow-border transition-[box-shadow] duration-[var(--motion-quick)] hover:shadow-border-hover"
              >
                <GuestThumb guest={thread.other} className="size-14 rounded-full" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{thread.other.displayName}</p>
                  <p className="truncate text-sm text-muted">
                    {thread.last?.body ?? "You matched. Say hello."}
                  </p>
                </div>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Conversation({
  meId,
  thread,
  onBack,
  onChanged,
}: {
  meId: string;
  thread: Thread;
  onBack: () => void;
  onChanged: () => void;
}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  const load = async () => {
    const rows = await listMessages({ data: { otherId: thread.other.userId } });
    setMessages(rows);
  };

  useEffect(() => {
    void load();
  }, [thread.other.userId]);

  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTop = node.scrollHeight;
  }, [messages.length]);

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (!body.trim() || busy) return;
    setBusy(true);
    try {
      await sendMessage({ data: { otherId: thread.other.userId, body } });
      setBody("");
      await load();
      onChanged();
    } finally {
      setBusy(false);
    }
  };

  const block = async () => {
    await blockGuest({ data: { otherId: thread.other.userId } });
    onChanged();
    onBack();
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      <header className="flex shrink-0 items-center gap-3">
        <Button type="button" variant="ghost" onClick={onBack}>
          Back
        </Button>
        <GuestThumb guest={thread.other} className="size-10 rounded-full" />
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium">{thread.other.displayName}</p>
          <p className="text-xs text-muted">{thread.other.city}</p>
        </div>
        <Button type="button" variant="ghost" onClick={() => void block()}>
          Block
        </Button>
      </header>

      <div
        ref={scroller}
        className="flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto rounded-lg bg-surface p-4 shadow-border"
      >
        {messages.length === 0 ? (
          <p className="text-sm text-muted">
            You matched with {thread.other.displayName}. Say hello.
          </p>
        ) : (
          messages.map((message) => {
            const mine = message.senderId === meId;
            return (
              <p
                key={message.id}
                className={cn(
                  "max-w-[85%] rounded-md px-3 py-2 text-sm leading-relaxed",
                  mine
                    ? "self-end bg-accent text-accent-fg"
                    : "self-start bg-elevated text-fg",
                )}
              >
                {message.body}
              </p>
            );
          })
        )}
      </div>

      <form onSubmit={onSubmit} className="flex shrink-0 gap-2">
        <Input
          value={body}
          onChange={(e) => setBody(e.target.value)}
          maxLength={500}
          placeholder="Message"
          aria-label="Message"
        />
        <Button type="submit" disabled={busy || !body.trim()}>
          Send
        </Button>
      </form>
    </div>
  );
}
