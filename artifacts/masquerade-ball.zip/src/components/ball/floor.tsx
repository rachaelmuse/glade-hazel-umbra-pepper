"use client";

import { useEffect, useRef, useState, type PointerEvent } from "react";
import { Heart, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { GuestCard, GuestThumb } from "@/components/ball/guest-card";
import { SignInButtons } from "@/components/ball/sign-in-buttons";
import { askToDance, passBy } from "@/lib/ball/actions";
import type { Profile } from "@/lib/ball/types";
import { cn } from "@/lib/utils";

const THRESHOLD = 108;

type Props = {
  guests: Profile[];
  signedIn: boolean;
  me?: Profile | null;
  onChanged: () => void;
  onOpenChat?: (otherId: string) => void;
};

export function Floor({ guests, signedIn, me, onChanged, onOpenChat }: Props) {
  const [busy, setBusy] = useState(false);
  const [askSignIn, setAskSignIn] = useState(false);
  const [match, setMatch] = useState<Profile | null>(null);
  const [drag, setDrag] = useState({ dx: 0, dy: 0, live: false, flying: false });
  const origin = useRef({ x: 0, y: 0 });
  const pos = useRef({ dx: 0, dy: 0, live: false });
  const busyRef = useRef(false);
  const guest = guests[0];
  const next = guests[1];

  useEffect(() => {
    pos.current = { dx: 0, dy: 0, live: false };
    setDrag({ dx: 0, dy: 0, live: false, flying: false });
    setAskSignIn(false);
  }, [guest?.userId]);

  const reduced =
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const flyTo = (dir: 1 | -1) => {
    const width = typeof window === "undefined" ? 480 : window.innerWidth;
    const nextPos = {
      dx: dir * Math.max(width, 420),
      dy: 28 * dir,
      live: false,
      flying: true,
    };
    pos.current = { dx: nextPos.dx, dy: nextPos.dy, live: false };
    setDrag(nextPos);
  };

  const like = async () => {
    if (!guest || busyRef.current) return;
    if (!signedIn) {
      pos.current = { dx: 0, dy: 0, live: false };
      setAskSignIn(true);
      setDrag({ dx: 0, dy: 0, live: false, flying: false });
      return;
    }
    busyRef.current = true;
    setBusy(true);
    if (!reduced) flyTo(1);
    try {
      const result = await askToDance({ data: { toId: guest.userId } });
      if (!reduced) await wait(200);
      if (result.status === "accepted") setMatch(guest);
      else onChanged();
    } finally {
      busyRef.current = false;
      setBusy(false);
      pos.current = { dx: 0, dy: 0, live: false };
      setDrag({ dx: 0, dy: 0, live: false, flying: false });
    }
  };

  const pass = async () => {
    if (!guest || busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    if (!reduced) flyTo(-1);
    try {
      if (signedIn) await passBy({ data: { toId: guest.userId } });
      if (!reduced) await wait(200);
      onChanged();
    } finally {
      busyRef.current = false;
      setBusy(false);
      pos.current = { dx: 0, dy: 0, live: false };
      setDrag({ dx: 0, dy: 0, live: false, flying: false });
    }
  };

  const onPointerDown = (event: PointerEvent<HTMLDivElement>) => {
    if (busyRef.current || !guest) return;
    origin.current = { x: event.clientX, y: event.clientY };
    pos.current = { dx: 0, dy: 0, live: true };
    event.currentTarget.setPointerCapture(event.pointerId);
    setDrag({ dx: 0, dy: 0, live: true, flying: false });
  };

  const onPointerMove = (event: PointerEvent<HTMLDivElement>) => {
    if (!pos.current.live) return;
    const dx = event.clientX - origin.current.x;
    const dy = (event.clientY - origin.current.y) * 0.35;
    pos.current = { dx, dy, live: true };
    setDrag({ dx, dy, live: true, flying: false });
  };

  const onPointerUp = () => {
    if (!pos.current.live) return;
    const dx = pos.current.dx;
    pos.current = { ...pos.current, live: false };
    if (dx > THRESHOLD) void like();
    else if (dx < -THRESHOLD) void pass();
    else {
      pos.current = { dx: 0, dy: 0, live: false };
      setDrag({ dx: 0, dy: 0, live: false, flying: false });
    }
  };

  if (match) {
    return (
      <MatchPanel
        guest={match}
        me={me}
        onKeep={() => {
          setMatch(null);
          onChanged();
        }}
        onMessage={() => {
          const id = match.userId;
          setMatch(null);
          onChanged();
          onOpenChat?.(id);
        }}
      />
    );
  }

  if (!guest) {
    return (
      <div className="flex h-full flex-col justify-center gap-3 px-1">
        <h1 className="font-display text-4xl tracking-display">You’re caught up</h1>
        <p className="text-pretty text-base leading-relaxed text-muted">
          That’s everyone nearby for now. Matches and likes live in the tab below.
        </p>
      </div>
    );
  }

  const likeOpacity = clamp(drag.dx / 120);
  const nopeOpacity = clamp(-drag.dx / 120);

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      <div className="relative min-h-0 flex-1">
        {next ? (
          <div className="absolute inset-0">
            <GuestCard guest={next} />
          </div>
        ) : null}

        <div
          className={cn(
            "absolute inset-0 touch-none select-none",
            drag.live ? "cursor-grabbing" : "cursor-grab",
          )}
          style={{
            transform: `translate(${drag.dx}px, ${drag.dy}px) rotate(${drag.dx / 18}deg)`,
            transition:
              drag.live
                ? "none"
                : "transform 220ms var(--ease-out)",
          }}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
        >
          <GuestCard
            guest={guest}
            likeOpacity={likeOpacity}
            nopeOpacity={nopeOpacity}
          />
        </div>
      </div>

      {askSignIn ? (
        <div className="flex shrink-0 flex-col gap-3 rounded-lg bg-surface p-4 shadow-border">
          <p className="text-sm text-muted">
            Sign in to like {guest.displayName} and start chatting.
          </p>
          <SignInButtons />
        </div>
      ) : (
        <div className="flex shrink-0 items-center justify-center gap-8 py-1">
          <Button
            type="button"
            variant="outline"
            size="lg"
            disabled={busy}
            onClick={() => void pass()}
            aria-label="Pass"
            className="size-16 rounded-full p-0"
          >
            <X className="size-7" />
          </Button>
          <Button
            type="button"
            size="lg"
            disabled={busy}
            onClick={() => void like()}
            aria-label="Like"
            className="size-16 rounded-full p-0"
          >
            <Heart className="size-7 fill-current" />
          </Button>
        </div>
      )}
    </div>
  );
}

function MatchPanel({
  guest,
  me,
  onKeep,
  onMessage,
}: {
  guest: Profile;
  me?: Profile | null;
  onKeep: () => void;
  onMessage: () => void;
}) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-6 px-2">
      <p className="text-xs font-medium tracking-kicker text-subtle uppercase">
        It’s a match
      </p>
      <div className="flex items-center">
        {me ? (
          <GuestThumb guest={me} className="size-28 rounded-full shadow-border" />
        ) : null}
        <GuestThumb
          guest={guest}
          className={cn("size-28 rounded-full shadow-border", me && "-ml-6")}
        />
      </div>
      <div className="flex flex-col items-center gap-2 text-center">
        <h2 className="font-display text-4xl tracking-display">{guest.displayName}</h2>
        <p className="max-w-sm text-pretty text-sm leading-relaxed text-muted">
          You both liked each other. Say hello, or keep looking.
        </p>
      </div>
      <div className="flex w-full flex-col gap-2">
        <Button type="button" size="lg" className="w-full" onClick={onMessage}>
          Message
        </Button>
        <Button type="button" variant="outline" size="lg" className="w-full" onClick={onKeep}>
          Keep swiping
        </Button>
      </div>
    </div>
  );
}

function clamp(n: number) {
  return Math.max(0, Math.min(1, n));
}

function wait(ms: number) {
  return new Promise((resolve) => {
    window.setTimeout(resolve, ms);
  });
}
