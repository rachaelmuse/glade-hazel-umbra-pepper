"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MatchTile } from "@/components/ball/guest-card";
import { respondToDance } from "@/lib/ball/actions";
import type { Invitation } from "@/lib/ball/types";

type Props = {
  invitations: Invitation[];
  onOpenThread: (otherId: string) => void;
  onChanged: () => void;
};

export function DanceCard({ invitations, onOpenThread, onChanged }: Props) {
  const inbound = invitations.filter((i) => i.inbound && i.status === "pending");
  const accepted = invitations.filter((i) => i.status === "accepted");
  const sent = invitations.filter((i) => !i.inbound && i.status === "pending");

  return (
    <div className="flex flex-col gap-8 pb-4">
      <header className="flex flex-col gap-1">
        <h1 className="font-display text-4xl tracking-display">Matches</h1>
        <p className="text-sm text-muted">
          {accepted.length} match{accepted.length === 1 ? "" : "es"}
        </p>
      </header>

      <section className="flex flex-col gap-3">
        <h2 className="text-xs font-medium tracking-label text-subtle uppercase">
          Liked you
        </h2>
        {inbound.length === 0 ? (
          <p className="text-sm text-muted">No new likes yet.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {inbound.map((invite) => (
              <div key={invite.id} className="flex flex-col gap-2">
                <MatchTile guest={invite.other} footer={invite.other.city} />
                <Respond id={invite.id} onChanged={onChanged} />
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-xs font-medium tracking-label text-subtle uppercase">
          Your matches
        </h2>
        {accepted.length === 0 ? (
          <p className="text-sm text-muted">
            Swipe right on Discover. If they like you back, they land here.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {accepted.map((invite) => (
              <MatchTile
                key={invite.id}
                guest={invite.other}
                footer="Say hello"
                onClick={() => onOpenThread(invite.other.userId)}
              />
            ))}
          </div>
        )}
      </section>

      {sent.length > 0 ? (
        <section className="flex flex-col gap-3">
          <h2 className="text-xs font-medium tracking-label text-subtle uppercase">
            Waiting
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {sent.map((invite) => (
              <MatchTile
                key={invite.id}
                guest={invite.other}
                footer="Waiting"
              />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

function Respond({ id, onChanged }: { id: number; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const act = async (accept: boolean) => {
    setBusy(true);
    try {
      await respondToDance({ data: { id, accept } });
      onChanged();
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="grid grid-cols-2 gap-2">
      <Button
        type="button"
        variant="outline"
        disabled={busy}
        onClick={() => void act(false)}
      >
        Pass
      </Button>
      <Button type="button" disabled={busy} onClick={() => void act(true)}>
        Like
      </Button>
    </div>
  );
}
