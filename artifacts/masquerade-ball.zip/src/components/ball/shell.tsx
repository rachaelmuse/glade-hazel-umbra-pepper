"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import { Compass, Heart, MessageCircle, UserRound } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { Cloakroom } from "@/components/ball/cloakroom";
import { DanceCard } from "@/components/ball/dance-card";
import { Floor } from "@/components/ball/floor";
import { Salon } from "@/components/ball/salon";
import {
  getMyProfile,
  listDanceCard,
  listFloor,
  listThreads,
} from "@/lib/ball/actions";
import type { Invitation, Profile, Thread } from "@/lib/ball/types";
import { cn } from "@/lib/utils";

type Tab = "floor" | "card" | "salon" | "mask";

export function BallShell({ userId }: { userId: string }) {
  const [tab, setTab] = useState<Tab>("floor");
  const [profile, setProfile] = useState<Profile | null | undefined>(undefined);
  const [guests, setGuests] = useState<Profile[]>([]);
  const [invites, setInvites] = useState<Invitation[]>([]);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const me = await getMyProfile();
    setProfile(me);
    if (!me) return;
    const [floor, card, salon] = await Promise.all([
      listFloor(),
      listDanceCard(),
      listThreads(),
    ]);
    setGuests(floor.guests);
    setInvites(card);
    setThreads(salon);
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  if (profile === undefined) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg text-muted">
        <p className="text-sm">Looking around…</p>
      </main>
    );
  }

  if (!profile) {
    return (
      <main className="relative min-h-dvh bg-bg text-fg">
        <div className="hero-wash pointer-events-none absolute inset-0" aria-hidden />
        <header className="relative mx-auto flex h-14 w-full max-w-lg items-center justify-between px-5">
          <Brand />
          <UserButton />
        </header>
        <div className="relative mx-auto w-full max-w-lg px-5 py-6">
          <Cloakroom onSaved={() => void refresh()} />
        </div>
      </main>
    );
  }

  const pending = invites.filter((i) => i.inbound && i.status === "pending").length;
  const fill = tab === "floor" || (tab === "salon" && Boolean(openId));

  return (
    <main className="relative flex min-h-dvh flex-col overflow-hidden bg-bg text-fg overscroll-none">
      <div className="hero-wash pointer-events-none absolute inset-0" aria-hidden />
      <header className="relative z-10 mx-auto flex h-14 w-full max-w-lg shrink-0 items-center justify-between px-5">
        <Brand />
        <UserButton />
      </header>

      <div
        className={cn(
          "relative z-10 mx-auto flex w-full max-w-lg flex-1 flex-col px-4 pb-24",
          fill ? "min-h-0" : "overflow-y-auto pt-4",
        )}
      >
        {tab === "floor" ? (
          <Floor
            guests={guests}
            signedIn
            me={profile}
            onChanged={() => void refresh()}
            onOpenChat={(id) => {
              setOpenId(id);
              setTab("salon");
            }}
          />
        ) : null}
        {tab === "card" ? (
          <DanceCard
            invitations={invites}
            onOpenThread={(id) => {
              setOpenId(id);
              setTab("salon");
            }}
            onChanged={() => void refresh()}
          />
        ) : null}
        {tab === "salon" ? (
          <Salon
            meId={userId}
            threads={threads}
            openId={openId}
            onOpen={setOpenId}
            onChanged={() => void refresh()}
          />
        ) : null}
        {tab === "mask" ? (
          <Cloakroom existing={profile} onSaved={() => void refresh()} />
        ) : null}
      </div>

      <nav
        className="fixed inset-x-0 bottom-0 z-10 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)]"
        aria-label="Dating"
      >
        <div className="mx-auto grid max-w-lg grid-cols-4">
          <NavBtn
            label="Discover"
            active={tab === "floor"}
            onClick={() => setTab("floor")}
            icon={<Compass className="size-5" />}
          />
          <NavBtn
            label="Matches"
            active={tab === "card"}
            onClick={() => setTab("card")}
            icon={<Heart className="size-5" />}
            badge={pending}
          />
          <NavBtn
            label="Chat"
            active={tab === "salon"}
            onClick={() => setTab("salon")}
            icon={<MessageCircle className="size-5" />}
          />
          <NavBtn
            label="Profile"
            active={tab === "mask"}
            onClick={() => setTab("mask")}
            icon={<UserRound className="size-5" />}
          />
        </div>
      </nav>
    </main>
  );
}

export function Brand() {
  return (
    <div className="flex flex-col leading-none">
      <span className="text-xs font-medium tracking-kicker text-subtle uppercase">
        Dating
      </span>
      <span className="font-display text-xl tracking-display">Masquerade Ball</span>
    </div>
  );
}

function NavBtn({
  label,
  active,
  onClick,
  icon,
  badge = 0,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  badge?: number;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "relative flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium",
        active ? "text-fg" : "text-subtle",
      )}
    >
      {icon}
      {label}
      {badge > 0 ? (
        <span className="absolute right-1/4 top-2 size-1.5 rounded-full bg-fg" />
      ) : null}
    </button>
  );
}
