"use client";

import { GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { Button } from "@/components/ui/button";

export function SignInButtons() {
  return (
    <div className="flex flex-col gap-2">
      {GROK_PROVIDERS.map((provider) => (
        <Button
          key={provider.providerId}
          type="button"
          size="lg"
          variant={provider.providerId === "grok-google" ? "solid" : "outline"}
          className="w-full"
          onClick={() => signIn(provider.providerId, { callbackURL: "/" })}
        >
          Continue with {provider.label}
        </Button>
      ))}
    </div>
  );
}
