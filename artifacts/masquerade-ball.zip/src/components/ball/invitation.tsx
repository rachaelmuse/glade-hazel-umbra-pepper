"use client";

import { GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { Button } from "@/components/ui/button";

export function Invitation() {
  return (
    <main className="relative min-h-dvh overflow-x-hidden bg-bg text-fg">
      <div className="hero-wash pointer-events-none absolute inset-0" aria-hidden />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-lg flex-col justify-center gap-8 px-5 py-16 sm:px-8">
        <p className="font-sans text-xs font-medium tracking-kicker text-subtle uppercase">
          Dating
        </p>
        <h1 className="font-display text-5xl leading-tight tracking-display sm:text-6xl">
          Masquerade Ball
        </h1>
        <div className="flex flex-col gap-4 text-pretty text-base leading-relaxed text-muted">
          <p>You already know. So does everyone here.</p>
          <p>
            Tonight is not about that. It is names, cities, the way someone
            laughs. No charts. No lectures. Just people.
          </p>
          <p className="text-sm text-subtle">18 and over.</p>
        </div>
        <div className="flex flex-col gap-2">
          {GROK_PROVIDERS.map((provider) => (
            <Button
              key={provider.providerId}
              type="button"
              size="lg"
              variant={provider.providerId === "grok-google" ? "solid" : "outline"}
              className="w-full"
              onClick={() => signIn(provider.providerId, { callbackURL: "/" })}
            >
              Continue with {provider.label}
            </Button>
          ))}
        </div>
      </div>
    </main>
  );
}
