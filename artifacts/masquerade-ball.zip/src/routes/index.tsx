import { createFileRoute } from "@tanstack/react-router";
import { BallHome } from "@/components/ball/home";
import { listPublicGuests } from "@/lib/ball/actions";

export const Route = createFileRoute("/")({
  loader: async () => ({ guests: await listPublicGuests() }),
  component: Home,
});

function Home() {
  const { guests } = Route.useLoaderData();
  return <BallHome initialGuests={guests} />;
}
