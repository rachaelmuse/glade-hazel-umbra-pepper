import { createFileRoute } from "@tanstack/react-router";
import { SignInButtons } from "@/components/ball/sign-in-buttons";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <main className="relative grid min-h-dvh place-items-center bg-bg px-5 text-fg">
      <div className="hero-wash pointer-events-none absolute inset-0" aria-hidden />
      <div className="relative flex w-full max-w-sm flex-col gap-6">
        <div className="flex flex-col gap-2">
          <p className="text-xs font-medium tracking-kicker text-subtle uppercase">
            Dating
          </p>
          <h1 className="font-display text-4xl tracking-display">Masquerade Ball</h1>
        </div>
        <p className="text-sm leading-relaxed text-muted">
          Sign in to like people and chat. 18 and over.
        </p>
        <SignInButtons />
      </div>
    </main>
  );
}
