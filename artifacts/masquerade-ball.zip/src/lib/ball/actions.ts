import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { isMaskId } from "@/lib/ball/masks";
import {
  HERE_AS,
  LOOKING_FOR,
  OPEN_TO,
  shuffle,
  threadKey,
  wants,
  type HereAs,
  type Invitation,
  type InviteStatus,
  type LookingFor,
  type Message,
  type OpenTo,
  type Profile,
  type ProfileInput,
  type Thread,
} from "@/lib/ball/types";

type ProfileRow = {
  user_id: string;
  display_name: string;
  age: number;
  city: string;
  here_as: string;
  open_to: string;
  looking_for: string;
  bio: string;
  mask: string;
  is_seed: boolean;
  photo: string;
};

type InviteRow = {
  id: number;
  from_id: string;
  to_id: string;
  status: string;
  created_at: string;
};

type MessageRow = {
  id: number;
  thread_key: string;
  sender_id: string;
  body: string;
  created_at: string;
};

const profileSchema = z.object({
  displayName: z.string().trim().min(1).max(32),
  age: z.number().int().min(18).max(99),
  city: z.string().trim().min(1).max(40),
  hereAs: z.enum(HERE_AS),
  openTo: z.enum(OPEN_TO),
  lookingFor: z.enum(LOOKING_FOR),
  bio: z.string().trim().max(280),
  mask: z.string().min(1).max(24).optional().default("rose"),
});

function asProfile(row: ProfileRow): Profile {
  return {
    userId: row.user_id,
    displayName: row.display_name,
    age: Number(row.age),
    city: row.city,
    hereAs: row.here_as as HereAs,
    openTo: row.open_to as OpenTo,
    lookingFor: row.looking_for as LookingFor,
    bio: row.bio,
    mask: row.mask,
    photo: row.photo || guestPhoto(row.user_id),
    isSeed: Boolean(row.is_seed),
  };
}

function guestPhoto(userId: string): string {
  if (!userId.startsWith("seed:")) return "";
  return `/guests/${userId.slice(5)}.jpg`;
}

function asMessage(row: MessageRow): Message {
  return {
    id: Number(row.id),
    threadKey: row.thread_key,
    senderId: row.sender_id,
    body: row.body,
    createdAt: String(row.created_at),
  };
}

const SEED_ACCEPT = [
  "It's a match. I was hoping you'd like me back.",
  "Yes. Don't be a stranger.",
  "I like you too. Say something true.",
  "Glad you asked. I was already looking.",
];

const SEED_REPLY = [
  "Tell me the best thing that happened this week.",
  "I'm here. No performance required.",
  "That made me smile. Keep going.",
  "Coffee or a walk — your call.",
];

function pickLine(id: string, lines: string[]): string {
  let n = 0;
  for (let i = 0; i < id.length; i++) n += id.charCodeAt(i);
  return lines[n % lines.length] ?? lines[0] ?? "";
}

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<ProfileRow>`
      select user_id, display_name, age, city, here_as, open_to, looking_for, bio, mask, is_seed, photo
      from profiles
      where user_id = ${context.userId}
      limit 1
    `;
    const row = rows[0];
    return row ? asProfile(row) : null;
  });

export const saveProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => profileSchema.parse(data))
  .handler(async ({ context, data }) => {
    const mask = isMaskId(data.mask) ? data.mask : "rose";
    const sql = await getSql();
    const existed = await sql<{ user_id: string }>`
      select user_id from profiles where user_id = ${context.userId} limit 1
    `;
    const isNew = !existed[0];
    await sql`
      insert into profiles (
        user_id, display_name, age, city, here_as, open_to, looking_for, bio, mask, is_seed, updated_at
      ) values (
        ${context.userId}, ${data.displayName}, ${data.age}, ${data.city},
        ${data.hereAs}, ${data.openTo}, ${data.lookingFor}, ${data.bio}, ${mask},
        false, now()
      )
      on conflict (user_id) do update set
        display_name = excluded.display_name,
        age = excluded.age,
        city = excluded.city,
        here_as = excluded.here_as,
        open_to = excluded.open_to,
        looking_for = excluded.looking_for,
        bio = excluded.bio,
        mask = excluded.mask,
        updated_at = now()
    `;

    if (isNew) {
      const seedRows = await sql<ProfileRow>`
        select user_id, display_name, age, city, here_as, open_to, looking_for, bio, mask, is_seed, photo
        from profiles
        where is_seed = true
      `;
      const likers = shuffle(seedRows.map(asProfile))
        .filter(
          (guest) =>
            wants(data.openTo, guest.hereAs) && wants(guest.openTo, data.hereAs),
        )
        .slice(0, 3);
      for (const liker of likers) {
        await sql`
          insert into invitations (from_id, to_id, status)
          values (${liker.userId}, ${context.userId}, 'pending')
          on conflict (from_id, to_id) do nothing
        `;
      }
    }

    return { ok: true as const };
  });

export const listPublicGuests = createServerFn({ method: "GET" }).handler(
  async () => {
    const sql = await getSql();
    const rows = await sql<ProfileRow>`
      select user_id, display_name, age, city, here_as, open_to, looking_for, bio, mask, is_seed, photo
      from profiles
      where is_seed = true
    `;
    return shuffle(rows.map(asProfile));
  },
);

export const listFloor = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const meRows = await sql<ProfileRow>`
      select user_id, display_name, age, city, here_as, open_to, looking_for, bio, mask, is_seed, photo
      from profiles where user_id = ${context.userId} limit 1
    `;
    const me = meRows[0] ? asProfile(meRows[0]) : null;
    if (!me) {
      const seeds = await sql<ProfileRow>`
        select user_id, display_name, age, city, here_as, open_to, looking_for, bio, mask, is_seed, photo
        from profiles
        where is_seed = true
      `;
      return { me: null, guests: shuffle(seeds.map(asProfile)) };
    }

    const rows = await sql<ProfileRow>`
      select user_id, display_name, age, city, here_as, open_to, looking_for, bio, mask, is_seed, photo
      from profiles
      where user_id <> ${context.userId}
        and user_id not in (select blocked_id from blocks where user_id = ${context.userId})
        and user_id not in (select user_id from blocks where blocked_id = ${context.userId})
        and user_id not in (
          select case when from_id = ${context.userId} then to_id else from_id end
          from invitations
          where (from_id = ${context.userId} or to_id = ${context.userId})
            and status in ('pending', 'accepted', 'passed', 'declined')
        )
    `;
    const guests = shuffle(
      rows
        .map(asProfile)
        .filter((guest) => wants(me.openTo, guest.hereAs) && wants(guest.openTo, me.hereAs)),
    );
    return { me, guests };
  });

export const listDanceCard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<InviteRow & ProfileRow>`
      select
        i.id, i.from_id, i.to_id, i.status, i.created_at::text as created_at,
        p.user_id, p.display_name, p.age, p.city, p.here_as, p.open_to, p.looking_for, p.bio, p.mask, p.is_seed, p.photo
      from invitations i
      join profiles p
        on p.user_id = case when i.from_id = ${context.userId} then i.to_id else i.from_id end
      where (i.from_id = ${context.userId} or i.to_id = ${context.userId})
        and i.status in ('pending', 'accepted')
        and p.user_id not in (select blocked_id from blocks where user_id = ${context.userId})
      order by i.created_at desc
    `;
    const invitations: Invitation[] = rows.map((row) => ({
      id: Number(row.id),
      fromId: row.from_id,
      toId: row.to_id,
      status: row.status as InviteStatus,
      createdAt: row.created_at,
      inbound: row.to_id === context.userId,
      other: asProfile(row),
    }));
    return invitations;
  });

export const askToDance = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => z.object({ toId: z.string().min(1) }).parse(data))
  .handler(async ({ context, data }) => {
    if (data.toId === context.userId) throw new Error("That's you.");
    const sql = await getSql();
    const blocked = await sql<{ n: number }>`
      select count(*)::int as n from blocks
      where (user_id = ${context.userId} and blocked_id = ${data.toId})
         or (user_id = ${data.toId} and blocked_id = ${context.userId})
    `;
    if ((blocked[0]?.n ?? 0) > 0) throw new Error("They're not available.");

    const otherRows = await sql<{ is_seed: boolean }>`
      select is_seed from profiles where user_id = ${data.toId} limit 1
    `;
    const other = otherRows[0];
    if (!other) throw new Error("They're no longer here.");

    const status = other.is_seed ? "accepted" : "pending";
    await sql`
      insert into invitations (from_id, to_id, status)
      values (${context.userId}, ${data.toId}, ${status})
      on conflict (from_id, to_id) do nothing
    `;

    if (other.is_seed) {
      const key = threadKey(context.userId, data.toId);
      const body = pickLine(data.toId, SEED_ACCEPT);
      await sql`
        insert into messages (thread_key, sender_id, body)
        values (${key}, ${data.toId}, ${body})
      `;
    }
    return { ok: true as const, status };
  });

export const passBy = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => z.object({ toId: z.string().min(1) }).parse(data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into invitations (from_id, to_id, status)
      values (${context.userId}, ${data.toId}, 'passed')
      on conflict (from_id, to_id) do nothing
    `;
    return { ok: true as const };
  });

export const respondToDance = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) =>
    z.object({
      id: z.number().int(),
      accept: z.boolean(),
    }).parse(data),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const status = data.accept ? "accepted" : "declined";
    await sql`
      update invitations
      set status = ${status}
      where id = ${data.id} and to_id = ${context.userId} and status = 'pending'
    `;
    if (data.accept) {
      const rows = await sql<{ from_id: string; is_seed: boolean }>`
        select i.from_id, p.is_seed
        from invitations i
        join profiles p on p.user_id = i.from_id
        where i.id = ${data.id}
        limit 1
      `;
      const from = rows[0];
      if (from?.is_seed) {
        const key = threadKey(context.userId, from.from_id);
        const body = pickLine(from.from_id, SEED_ACCEPT);
        await sql`
          insert into messages (thread_key, sender_id, body)
          values (${key}, ${from.from_id}, ${body})
        `;
      }
    }
    return { ok: true as const };
  });

export const listThreads = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const partners = await sql<ProfileRow>`
      select p.user_id, p.display_name, p.age, p.city, p.here_as, p.open_to, p.looking_for, p.bio, p.mask, p.is_seed, p.photo
      from invitations i
      join profiles p
        on p.user_id = case when i.from_id = ${context.userId} then i.to_id else i.from_id end
      where i.status = 'accepted'
        and (i.from_id = ${context.userId} or i.to_id = ${context.userId})
        and p.user_id not in (select blocked_id from blocks where user_id = ${context.userId})
    `;
    const threads: Thread[] = [];
    for (const row of partners) {
      const other = asProfile(row);
      const key = threadKey(context.userId, other.userId);
      const lastRows = await sql<MessageRow>`
        select id, thread_key, sender_id, body, created_at::text as created_at
        from messages
        where thread_key = ${key}
        order by created_at desc, id desc
        limit 1
      `;
      threads.push({
        other,
        last: lastRows[0] ? asMessage(lastRows[0]) : null,
      });
    }
    threads.sort((a, b) => {
      const at = a.last?.createdAt ?? "";
      const bt = b.last?.createdAt ?? "";
      return bt.localeCompare(at);
    });
    return threads;
  });

export const listMessages = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => z.object({ otherId: z.string().min(1) }).parse(data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const allowed = await sql<{ n: number }>`
      select count(*)::int as n from invitations
      where status = 'accepted'
        and (
          (from_id = ${context.userId} and to_id = ${data.otherId})
          or (from_id = ${data.otherId} and to_id = ${context.userId})
        )
    `;
    if ((allowed[0]?.n ?? 0) === 0) return [] as Message[];
    const key = threadKey(context.userId, data.otherId);
    const rows = await sql<MessageRow>`
      select id, thread_key, sender_id, body, created_at::text as created_at
      from messages
      where thread_key = ${key}
      order by created_at asc, id asc
    `;
    return rows.map(asMessage);
  });

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) =>
    z.object({
      otherId: z.string().min(1),
      body: z.string().trim().min(1).max(500),
    }).parse(data),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const allowed = await sql<{ n: number }>`
      select count(*)::int as n from invitations
      where status = 'accepted'
        and (
          (from_id = ${context.userId} and to_id = ${data.otherId})
          or (from_id = ${data.otherId} and to_id = ${context.userId})
        )
    `;
    if ((allowed[0]?.n ?? 0) === 0) throw new Error("You can only message matches.");
    const key = threadKey(context.userId, data.otherId);
    await sql`
      insert into messages (thread_key, sender_id, body)
      values (${key}, ${context.userId}, ${data.body})
    `;
    const seed = await sql<{ is_seed: boolean }>`
      select is_seed from profiles where user_id = ${data.otherId} limit 1
    `;
    if (seed[0]?.is_seed) {
      const reply = pickLine(data.body + data.otherId, SEED_REPLY);
      await sql`
        insert into messages (thread_key, sender_id, body)
        values (${key}, ${data.otherId}, ${reply})
      `;
    }
    return { ok: true as const };
  });

export const blockGuest = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => z.object({ otherId: z.string().min(1) }).parse(data))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into blocks (user_id, blocked_id)
      values (${context.userId}, ${data.otherId})
      on conflict (user_id, blocked_id) do nothing
    `;
    await sql`
      update invitations
      set status = 'declined'
      where (from_id = ${context.userId} and to_id = ${data.otherId})
         or (from_id = ${data.otherId} and to_id = ${context.userId})
    `;
    return { ok: true as const };
  });

export type { ProfileInput };
