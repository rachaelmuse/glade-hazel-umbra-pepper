export const MASKS = [
  { id: "rose", label: "Rose" },
  { id: "crescent", label: "Crescent" },
  { id: "moth", label: "Moth" },
  { id: "lyre", label: "Lyre" },
  { id: "fox", label: "Fox" },
  { id: "compass", label: "Compass" },
  { id: "swan", label: "Swan" },
  { id: "flame", label: "Flame" },
  { id: "pearl", label: "Pearl" },
  { id: "ivy", label: "Ivy" },
  { id: "veil", label: "Veil" },
  { id: "coin", label: "Coin" },
] as const;

export type MaskId = (typeof MASKS)[number]["id"];

export function isMaskId(value: string): value is MaskId {
  return MASKS.some((mask) => mask.id === value);
}

export function MaskMark({ id, className }: { id: string; className?: string }) {
  const stroke = "currentColor";
  return (
    <svg
      viewBox="0 0 64 64"
      className={className}
      aria-hidden="true"
      fill="none"
    >
      <circle cx="32" cy="32" r="29" stroke={stroke} strokeWidth="1.25" opacity="0.35" />
      {glyph(id, stroke)}
    </svg>
  );
}

function glyph(id: string, stroke: string) {
  switch (id) {
    case "rose":
      return (
        <path
          d="M32 18c6 4 10 10 10 16 0 8-5 14-10 14s-10-6-10-14c0-6 4-12 10-16Z"
          stroke={stroke}
          strokeWidth="1.6"
        />
      );
    case "crescent":
      return (
        <path
          d="M38 16a16 16 0 1 0 0 32 18 18 0 1 1 0-32Z"
          stroke={stroke}
          strokeWidth="1.6"
        />
      );
    case "moth":
      return (
        <path
          d="M32 44V22M22 28c-6 2-10 8-8 14 6-2 12-4 18-4 6 0 12 2 18 4 2-6-2-12-8-14-4-8-12-8-16 0 0 0-2 2-4 4Z"
          stroke={stroke}
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
      );
    case "lyre":
      return (
        <path
          d="M24 18c0 14 4 26 8 26s8-12 8-26M22 22h20M26 30h12"
          stroke={stroke}
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      );
    case "fox":
      return (
        <path
          d="M16 28 32 16l16 12-6 20H22L16 28Z"
          stroke={stroke}
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
      );
    case "compass":
      return (
        <>
          <circle cx="32" cy="32" r="12" stroke={stroke} strokeWidth="1.6" />
          <path d="M32 16v6M32 42v6M16 32h6M42 32h6M32 32l8-10" stroke={stroke} strokeWidth="1.6" />
        </>
      );
    case "swan":
      return (
        <path
          d="M18 42c8 4 20 4 28-2 2-8-6-12-10-8 2-10-8-16-14-10 0 6 4 10 8 12"
          stroke={stroke}
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      );
    case "flame":
      return (
        <path
          d="M32 16c8 10 12 14 12 22a12 12 0 1 1-24 0c0-6 4-12 8-16 2 6 6 8 8 8-2-6-4-10-4-14Z"
          stroke={stroke}
          strokeWidth="1.6"
        />
      );
    case "pearl":
      return (
        <>
          <circle cx="32" cy="32" r="8" stroke={stroke} strokeWidth="1.6" />
          <circle cx="32" cy="32" r="16" stroke={stroke} strokeWidth="1.2" opacity="0.55" />
        </>
      );
    case "ivy":
      return (
        <path
          d="M20 44c8-8 8-16 4-22 8 2 14 8 16 16 2-8 8-12 14-12-8 10-8 18-6 24"
          stroke={stroke}
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      );
    case "veil":
      return (
        <path
          d="M18 22h28M22 22c0 16 4 24 10 24s10-8 10-24"
          stroke={stroke}
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      );
    case "coin":
      return (
        <>
          <circle cx="32" cy="32" r="14" stroke={stroke} strokeWidth="1.6" />
          <path d="M32 22v20M26 28h12M26 36h12" stroke={stroke} strokeWidth="1.5" />
        </>
      );
    default:
      return <circle cx="32" cy="32" r="10" stroke={stroke} strokeWidth="1.6" />;
  }
}
