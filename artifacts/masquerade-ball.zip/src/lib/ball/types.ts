export const HERE_AS = ["woman", "man", "nonbinary"] as const;
export const OPEN_TO = ["women", "men", "everyone"] as const;
export const LOOKING_FOR = ["conversation", "dancing", "company", "lasting"] as const;

export type HereAs = (typeof HERE_AS)[number];
export type OpenTo = (typeof OPEN_TO)[number];
export type LookingFor = (typeof LOOKING_FOR)[number];
export type InviteStatus = "pending" | "accepted" | "declined" | "passed";

export type Profile = {
  userId: string;
  displayName: string;
  age: number;
  city: string;
  hereAs: HereAs;
  openTo: OpenTo;
  lookingFor: LookingFor;
  bio: string;
  mask: string;
  photo: string;
  isSeed: boolean;
};

export type Invitation = {
  id: number;
  fromId: string;
  toId: string;
  status: InviteStatus;
  createdAt: string;
  other: Profile;
  inbound: boolean;
};

export type Message = {
  id: number;
  threadKey: string;
  senderId: string;
  body: string;
  createdAt: string;
};

export type Thread = {
  other: Profile;
  last: Message | null;
};

export type ProfileInput = {
  displayName: string;
  age: number;
  city: string;
  hereAs: HereAs;
  openTo: OpenTo;
  lookingFor: LookingFor;
  bio: string;
  mask: string;
  photo?: string;
};

export const LOOKING_LABEL: Record<LookingFor, string> = {
  conversation: "Conversation",
  dancing: "Dates",
  company: "Company",
  lasting: "Something lasting",
};

export const HERE_LABEL: Record<HereAs, string> = {
  woman: "Woman",
  man: "Man",
  nonbinary: "Nonbinary",
};

export const OPEN_LABEL: Record<OpenTo, string> = {
  women: "Women",
  men: "Men",
  everyone: "Everyone",
};

export function threadKey(a: string, b: string): string {
  return [a, b].sort().join(":");
}

export function wants(openTo: OpenTo, hereAs: HereAs): boolean {
  if (openTo === "everyone") return true;
  if (openTo === "women") return hereAs === "woman";
  if (openTo === "men") return hereAs === "man";
  return true;
}

export function milesAway(userId: string): number {
  let n = 0;
  for (let i = 0; i < userId.length; i++) {
    n = (n + userId.charCodeAt(i) * (i + 3)) % 19;
  }
  return n + 1;
}

export function shuffle<T>(items: T[]): T[] {
  const next = items.slice();
  for (let i = next.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const a = next[i];
    const b = next[j];
    if (a === undefined || b === undefined) continue;
    next[i] = b;
    next[j] = a;
  }
  return next;
}
